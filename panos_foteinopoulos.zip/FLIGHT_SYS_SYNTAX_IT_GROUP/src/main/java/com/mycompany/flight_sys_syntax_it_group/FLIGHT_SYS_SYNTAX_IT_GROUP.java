/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.flight_sys_syntax_it_group;

/**
 *
 * @author pfoteinopoulos
 */

 import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class FLIGHT_SYS_SYNTAX_IT_GROUP extends JFrame {



    //initialize our values and the list with movies
    private List<Integer> movieDurationList; 
    private int flighttime = 0; 
    private JLabel resLabel;

    public FLIGHT_SYS_SYNTAX_IT_GROUP() {
        movieDurationList = new ArrayList<>(); //Creation of Arraylist for the list of movies
       
        //start of our GUI preferences
        setTitle("Syntax Movie Flight System");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
       
        JLabel movieLabel = new JLabel("Enter Movie Durations (separated by spaces):");//eg 80 60 90 90 100 120 45
        JTextField movieField = new JTextField();
        JLabel flightLabel = new JLabel("Enter your flight duration (in minutes):"); //eg 250 
        JTextField flightField = new JTextField();
        JButton addyourMoviesButton = new JButton("Add your Movies");
        JButton suggestionButton = new JButton("Recommending for your flight");
        resLabel = new JLabel("Movies in your list are: ");

       //we are adding in our panel textfields, buttons and result label
        
        inputPanel.add(movieLabel);
        inputPanel.add(movieField);
        inputPanel.add(flightLabel);
        inputPanel.add(flightField);
        inputPanel.add(addyourMoviesButton);
        inputPanel.add(suggestionButton);

        addyourMoviesButton.addActionListener(new ActionListener() { //when clicked the button --> φτιαχνω τη μεθοδο μου για την πληκτρολογηση με κενα των λεπτων των ταινιων
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] movieDurationStrings = movieField.getText().split(" "); //περιμενω να πληκτρολογηθει κείμενο και μετο split μπορω να τα πληκτρολογω με κενα
                movieDurationList.clear();
                for (String movieDurationString : movieDurationStrings) {
                    movieDurationList.add(Integer.parseInt(movieDurationString.trim())); //https://stackoverflow.com/questions/21062638/string-trim-method
                }
                movieField.setText("");
            }
        });
        //αντίστοιχα όταν πατάω το suggestionbutton
        suggestionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                flighttime = Integer.parseInt(flightField.getText().trim());

                int[] result = findRecommendedMovies(movieDurationList, flighttime); //we call the findRecommendingMovies method
                resLabel.setText("Result: [" + result[0] + ", " + result[1] + "]");
            }
        });

        mainPanel.add(inputPanel, BorderLayout.CENTER);
        mainPanel.add(resLabel, BorderLayout.SOUTH);
        add(mainPanel);
    }

    public int[] findRecommendedMovies(List<Integer> movieDurations, int flightDuration) {
        int[] result = new int[2]; //θελουμε 2 παραμέτρους για αυτο στον πινακα βαζω 2 μεγεθος αφου θελω [διάρκειαταινιών_από_λίστα, διάρκεια_πτήσηςμου]
        int desiredDuration = flightDuration - 30; // 30 minutes less than flight duration βάσει αυτό που μου δόθηκε

        int maxtime = 0; //initialize the maximum time

        for (int i = 0; i < movieDurations.size(); i++) { //first movies
            for (int j = i + 1; j < movieDurations.size(); j++) { //second movie
                int totalRuntime = movieDurations.get(i) + movieDurations.get(j); //τις προσθέτω
                if (totalRuntime <= desiredDuration && totalRuntime > maxtime) { //αν ειναι μικρότερο ή ισο απο επιθυμητο χρόνο αλλα και μεγαλυτερο απο το maxtime
                    result[0] = i; //to result tis protis 
                    result[1] = j;//kai 2hs tainias
                   // maxtime = totalRuntime;
                }
            }
        }

        return result; //
    }

    public static void main(String[] args) {
        
            FLIGHT_SYS_SYNTAX_IT_GROUP gui = new FLIGHT_SYS_SYNTAX_IT_GROUP(); //our object in main
            gui.setVisible(true);
       
    }
}
